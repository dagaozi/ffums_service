define({
  "name": "接口文档",
  "version": "0.1.0",
  "description": "脂肪肝随访系统",
  "title": "随访接口文档",
  "url": "10.11.74.14:8003/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-15T14:33:13.074Z",
    "url": "http://apidocjs.com",
    "version": "0.22.1"
  }
});
